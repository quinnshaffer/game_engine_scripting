﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddMass : MonoBehaviour
{
    public float InitialMass = 0f;
    public float IncrementMassBy = 0.01f;
    private Rigidbody rb = null;
    // Start is called before the first frame update
    void Start()
    {
    
        
    }

    // Update is called once per frame
    void Update()
    {
        if (rb != null)
        {
            
        }
    }
}
