﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveCenterTile : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject centerTile;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
