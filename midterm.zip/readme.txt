Github: https://github.com/quinnshaffer/game_engine_scripting/tree/main/midterm
Itch: https://qdshaffer.itch.io/ghosts